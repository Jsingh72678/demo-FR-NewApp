# REACT/NODE Fund raising App

## Brief Description
A funding platform where user can browse through different campaigns and support the cause by donating some amount of money.
The payment is done via the ptm gateway & complete transparency and anonymity of the process is ensured.

## Features and Functionalities

**User features**
 - User can see the ongoing campaigns on the landing page.
 - User can click on the campaign they want to support and then be directed to the specific campaign page where they can see the campaign details.
 - User can then support the campaign by donating the amount they would like to via pTm.
 - User can also share the campaign among their friends/colleagues/relatives to increase the reach of the campaign via the share-feature.
 - User can see the amount details of the transaction after the payment is done on that campaign page in the List of Donation.
 - User can send us their queries via the form provided in the 'Contact-Us' section.

 **Admin features**

 - All above features are included for the admin as well.
**CRUD**

 ## Tech Stack

 **MERN** stack has been used for the development of this website.
 - [React.js](https://reactjs.org/)
 - [Node.js](https://nodejs.org/en/)
 - [Express.js](https://expressjs.com/)
 - [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)

## API :

 - [PayTM API](https://developer.paytm.com/docs/)

## Components include:
 - API calling (calling to PayTM gateway)
 - Usage of MongoDB that provides us a Schema-less Database and ensures high performance and efficiency.


## SetUp Steps

### Prerequisites
npm installed, Paytm id, MongoDB URI, create-react-app installed, etc. <br>
### For Backend
 - Go to backend folder.
 - Run npm install
 - Set Up Environment variable as shown in `env-sample` file.
 - Run `node ./server.js`

### For Frontend
 - Go to `Frontend/crowd-funding-frontend` folder.
 - Run `npm install`
 - Put backend url in config.js
 - Run `npm start`

**Your app is now running on port 3000 in your browser**
