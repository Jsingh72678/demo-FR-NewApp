# REACT/NODE Fund raising App

## Brief Description
A funding platform.
The payment is done via the ptm gateway.

## Features and Functionalities

**User features**
**Admin features**

##CRUD

 ## Tech Stack

 **MERN** stack has been used for the development of this website.
 - [React.js](https://reactjs.org/)
 - [Node.js](https://nodejs.org/en/)
 - [Express.js](https://expressjs.com/)
 - [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)

## API :

 - [PayTM API](https://developer.paytm.com/docs/)

## Components include:
 - Payment Api
 - Mongo DB


## SetUp Steps

### Prerequisites
To - npm installed, payment - Paytm id, Db - MongoDB URI, command - create-react-app installed, etc.
### For Backend
 - Go to backend folder.
 - Run npm install
 - Set Up Environment variable as shown in `env-sample` file.
 - Run `node ./server.js`

### For Frontend
 - Go to `Frontend/crowd-funding-frontend` folder.
 - Run `npm install`
 - Put backend url in config.js
 - Run `npm start`

**App running on port 3000 in your browser**
